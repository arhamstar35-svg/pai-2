# Pandas Learning Notes

A beginner-friendly Pandas reference containing the functions, methods, and
attributes covered in my learning sessions, with comments and runnable examples.

## Topics covered

1. Creating DataFrames
2. Reading and writing CSV, Excel, and JSON files
3. Inspecting DataFrames
4. Selecting columns and rows (`loc`, `iloc`, `at`, `iat`)
5. Filtering rows with conditions
6. Adding, changing, and removing columns
7. Handling missing values
8. Mapping values with `map()`
9. Mathematical and statistical methods
10. Sorting data
11. Grouping by one or multiple columns
12. Aggregation with `agg()`
13. `transform()`, `filter()`, `apply()`, and `get_group()`
14. Combining DataFrames with `concat()` and `merge()`

## Requirements

- Python 3
- pandas
- openpyxl (only needed for Excel files)

Install the packages:

```bash
pip install pandas openpyxl
```

## Run the examples

```bash
python pandas_learning_notes.py
```

The CSV, Excel, and JSON file I/O examples are commented out because they
require files to be present in the project folder. Uncomment them when you
have the corresponding files.

## Important note about Pandas 3

`DataFrame.append()` has been removed from modern Pandas versions.
Use `pd.concat()` to combine DataFrames instead.

## Example: groupby with multiple columns

```python
grouped = df.groupby(["Department", "Age"])
print(grouped["Salary"].sum())
```

Pandas creates a separate group for every unique combination of Department
and Age. For example, `("IT", 22)` and `("HR", 22)` are different groups.

## Suggested repository structure

```text
pandas-learning-notes/
├── README.md
└── pandas_learning_notes.py
```

## Learning purpose

These notes are for revision and practice. Examples use small datasets so
that the output and each operation are easy to understand.
